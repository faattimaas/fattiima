<?php

    session_start();
    require_once('includes/hybridauth/src/autoload.php');

    if(isset($_SESSION["user_email"]))
    {
        header("location:http://localhost/demo/auth22/login2.php");
    }

    use Hybridauth\Exception\Exception;
    use Hybridauth\Hybridauth;
    use Hybridauth\HttpClient;

    if($_GET["request"] == "google" || $_GET["request"] == "facebook")
    {
        $provider = $_GET["request"];
        $config = [
            'callback' => "https://tijuana.doctor/auth/callback.php?request=$provider",
            'providers' => [
                'Google' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => 'insert id',
                        'secret' => 'insert key',
                    ]
                ],
                'Facebook' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => 'insert id',
                        'secret' => 'insert key',
                    ]
                ]
            ]
        ];
    }

    else
    {
        HttpClient\Util::redirect('http://localhost/demo/auth22/login2.php');
    }

    try
    {

        $hybridauth = new Hybridauth($config);

        $hybridauth->authenticate(ucfirst($provider));

        $adapters = $hybridauth->getConnectedAdapters();

        $userInfo = $adapters[ucfirst($provider)]->getUserProfile();

        // ******************************************************
        //  Now that we have data on the user,
        // this is where you would store it in YOUR database
        // ******************************************************

        $email = $userInfo->email;
        // $fullname = $userInfo->firstName." ".$userInfo->lastName;
        $user_avatar = $userInfo->photoURL;
        // $username = explode("@", $userInfo->email)[0];
        // $phone = $userInfo->phone;

        $_SESSION["admin_email"] = $email;
        $_SESSION['admin_pic'] = $user_avatar;

        /**
        * Redirects user to home page (i.e., index.php in our case)
        */
        HttpClient\Util::redirect('http://localhost/demo/auth22/index.php');

    }
    catch (Exception $e)
    {
        echo $e->getMessage();
    }
?>
